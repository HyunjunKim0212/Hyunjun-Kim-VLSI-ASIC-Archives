* The first line is always a comment line.
* Case-insensitive

* Control
.option post INGOLD=2

* Include the following file to load transistor models.
.include './45nm_PTM_HP_v2.1.pm'

* Parameters
* Supply voltage
.param Vsup = 1.0V

* Inverter. use NMOS_HP and PMOS_HP for NMOS and PMOS transistors.

*** Transistor names should begin with "m".
*** Use "nXXXXX" for node names.
*** Use 0 for the ground.
* Format: <transistor name> <drain> <gate> <source> <body> <type> L(Length) W(Width)

* purse generator
mp1 nInv1 nClk nVdd nVdd PMOS_HP L=45n W=70n
mp2 nInv2 nInv1 nVdd nVdd PMOS_HP L=45n W=70n
mp3 nInv3 nInv2 nVdd nVdd PMOS_HP L=45n W=70n

mn1 nInv1 nClk 0  0 NMOS_HP L=45n W=50n
mn2 nInv2 nInv1 0 0 NMOS_HP L=45n W=50n 
mn3 nInv3 nInv2  0 0 NMOS_HP L=45n W=50n

*Loop1
mp4 nInv4 na  nVdd nVdd PMOS_HP L=45n W=70n
mp5 na1 nInv4 nVdd nVdd PMOS_HP L=45n W=70n

mn4 nInv4 na  0 0 NMOS_HP L=45n  W=50n
mn5 na1 nInv4 0 0 NMOS_HP L=45n W=50n

*Loop2
mp6 nInv6 ne nVdd nVdd PMOS_HP L=45n W=70n
mp7 ne1 nInv6 nVdd nVdd PMOS_HP L=45n W=70n

mn6 nInv6 ne 0 0 NMOS_HP L=45n W=50n
mn7 ne1 nInv6 0 0 NMOS_HP L=45n W=50n

*inverter
mp8 nY ne1 nVdd nVdd PMOS_HP L=45n W=70n
mn8 nY ne1 0 0 NMOS_HP L=45n W=50n

*right
mp9 na nClk nVdd nVdd PMOS_HP L=45n W=70n
mn9 na nD nb 0 NMOS_HP L=45n W=50n 
mn10 nb nClk nc 0 NMOS_HP L=45n W=50n
mn11 nc nInv3 0 0 NMOS_HP L=45n W=50n

*left
mp10 ne na1 nVdd nVdd PMOS_HP L=45n W=70n
mn12 ne nClk nf 0 NMOS_HP L=45n W=50n
mn13 nf na1 0 0 NMOS_HP L=45n W=50n

*** Output load capacitance. Capacitors should begin with "c".
* Format: <capacitor name> <node 1> <node 2> <value>
cout nY 0 10f

* Power supply
* Format: <power supply name> <node 1> <node 2> <value>
*** Voltage source names should begin with "v".
VVdd nVdd 0 Vsup

* Input signal (independent voltage source)
* Format: <signal name> <node 1> <node 2> <signal>
* For the signal, we use a piecewise linear (PWL) source. Format: ... PWL time1 value1 time2 value2 ...

VClk nClk 0 Pulse (0 Vsup 200p 10p 10p 490p 1n)
VD nD 0 PWL 0p 0 1n 0 1.01n Vsup 2n Vsup 2.01n 0
 
* Transient analysis. Simulate up to 2.5ns.
.tran 1p 3.5n
.measure tran avg_power avg power from 1n to 3n
.end

* The first line is always a comment line.
* Case-insensitive

* Control
.option post INGOLD=2

* Include the following file to load transistor models.
.include './45nm_PTM_HP_v2.1.pm'

* Parameters
* Supply voltage
.param Vsup = 1.0V

* Xor Gate. use NMOS_HP and PMOS_HP for NMOS and PMOS transistors.

*** Transistor names should begin with "m".
*** Use "nXXXXX" for node names.
*** Use 0 for the ground.
* Format: <transistor name> <drain> <gate> <source> <body> <type> L(Length) W(Width)

* Inverter

mAinvp nInvA nA nVdd nVdd PMOS_HP L=45n W=150n
mAinvn nInvA nA 0 0 NMOS_HP L=45n W=100n

mBinvp nInvB nB nVdd nVdd PMOS_HP L=45n W=150n
mBinvn nInvB nB 0 0 NMOS_HP L=45n W=100n

*XOR Gate

mp1 nC nA nVdd nVdd PMOS_HP L=45n W=150n
mp2 nY nInvB nC nVdd PMOS_HP L=45n W=150n
mp3 nD nInvA nVdd nVdd PMOS_HP L=45n W=150n
mp4 nY nB nD nVdd PMOS_HP L=45n W=150n

mn1 nY nInvA nE 0 NMOS_HP L=45n W=100n
mn2 nE nInvB 0 0 NMOS_HP L=45n W=100n
mn3 nY nA nF 0 NMOS_HP L=45n W=100n
mn4 nF nB 0 0 NMOS_HP L=45n W=100n

*** Output load capacitance. Capacitors should begin with "c".
* Format: <capacitor name> <node 1> <node 2> <value>
cout nY 0 10f

* Power supply
* Format: <power supply name> <node 1> <node 2> <value>
*** Voltage source names should begin with "v".
VVdd nVdd 0 Vsup

* Input signal (independent voltage source)
* Format: <signal name> <node 1> <node 2> <signal>
* For the signal, we use a piecewise linear (PWL) source. Format: ... PWL time1 value1 time2 value2 ...

VA nA 0 PWL 0p 0 1.5n 0 1.51n vSup 2.5n vSup 2.51n 0
VB nB 0 PWL 0p 0 0.01n 0 0.5n 0 0.51n Vsup 1n Vsup 1.01n 0 2n 0 2.01n Vsup 2.5n Vsup 2.51n 0

* Transient analysis. Simulate up to 2.5ns.
.tran 1p 3.5n
.measure tran avg_power avg power from 1n to 3n
.end



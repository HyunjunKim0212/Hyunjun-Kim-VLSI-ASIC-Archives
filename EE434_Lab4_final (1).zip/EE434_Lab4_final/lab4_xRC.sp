* File: lab4_xRC.sp
* Created: Sun Apr 26 23:30:42 2026
* Program "Calibre xRC"
* Version "v2020.3_24.16"
* 
.include "lab4_xRC.sp.pex"
.subckt lab4  A B C VDD VSS Y
* 
* Y	Y
* VSS	VSS
* VDD	VDD
* C	C
* B	B
* A	A
mnA N_N2_mnA_d N_A_mnA_g N_noxref_4_mnA_s N_VSS_mnA_b NMOS_HP L=5e-08 W=1.8e-07
+ AD=1.98e-14 AS=2.52e-14 PD=5.8e-07 PS=6.4e-07
mnB N_noxref_4_mnA_s N_B_mnB_g N_VSS_mnB_s N_VSS_mnA_b NMOS_HP L=5e-08 W=1.8e-07
+ AD=2.52e-14 AS=2.52e-14 PD=6.4e-07 PS=6.4e-07
mnC N_noxref_4_mnC_d N_C_mnC_g N_VSS_mnB_s N_VSS_mnA_b NMOS_HP L=5e-08 W=1.8e-07
+ AD=1.98e-14 AS=2.52e-14 PD=5.8e-07 PS=6.4e-07
mnInv N_Y_mnInv_d N_N2_mnInv_g N_VSS_mnInv_s N_VSS_mnA_b NMOS_HP L=5e-08
+ W=1.8e-07 AD=1.98e-14 AS=1.98e-14 PD=5.8e-07 PS=5.8e-07
mpA N_N2_mpA_d N_A_mpA_g N_VDD_mpA_s N_VDD_mpA_b PMOS_HP L=5e-08 W=1.4e-07
+ AD=1.54e-14 AS=1.54e-14 PD=5e-07 PS=5e-07
mpB noxref_11 N_B_mpB_g N_VDD_mpB_s N_VDD_mpA_b PMOS_HP L=5e-08 W=2.8e-07
+ AD=3.92e-14 AS=3.08e-14 PD=8.4e-07 PS=7.8e-07
mpC N_N2_mpC_d N_C_mpC_g noxref_11 N_VDD_mpA_b PMOS_HP L=5e-08 W=2.8e-07
+ AD=3.08e-14 AS=3.92e-14 PD=7.8e-07 PS=8.4e-07
mpInv N_Y_mpInv_d N_N2_mpInv_g N_VDD_mpInv_s N_VDD_mpA_b PMOS_HP L=5e-08
+ W=2.8e-07 AD=3.08e-14 AS=3.08e-14 PD=7.8e-07 PS=7.8e-07
*
.include "lab4_xRC.sp.LAB4.pxi"
*
.ends
*
*

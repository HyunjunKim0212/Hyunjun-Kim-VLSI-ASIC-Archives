* The first line is always a comment line.
* Case-insensitive

* Control
.option post INGOLD=2

* Include the following file to load transistor models.
.include './45nm_PTM_HP_v2.1.pm'

* Parameters
* Supply voltage
.param Vsup = 1.0V

* Inverter. use NMOS_HP and PMOS_HP for NMOS and PMOS transistors.

*** Transistor names should begin with "m".
*** Use "nXXXXX" for node names.
*** Use 0 for the ground.
* Format: <transistor name> <drain> <gate> <source> <body> <type> L(Length) W(Width)

* purse generator
minvp1 nInv1 nClk nVdd nVdd PMOS_HP L=45n W=180n
minvp2 nInv2 nInv1 nVdd nVdd PMOS_HP L=45n W=180n

minvn1 nInv1 nClk 0 0 NMOS_HP L=45n W=120n
mninv2 nInv2 nInv1 0 0 NMOS_HP L=45n W=120n 


*Loop1
minvp3 nInv3 na nVdd nVdd PMOS_HP L=45n W=180n
minvp4 na1 nInv3 nVdd nVdd PMOS_HP L=45n W=180n

minvn3 nInv3 na 0 0 NMOS_HP L=45n W=120n
minvn4 na1 nInv3 0 0 NMOS_HP L=45n W=120n

*Loop2
minvp5 nInv5 ne nVdd nVdd PMOS_HP L=45n W=180n
minvp6 ne1 nInv5 nVdd nVdd PMOS_HP L=45n W=180n

minvn5 nInv5 ne 0 0 NMOS_HP L=45n W=120n
minvn6 ne1 nInv5 0 0 NMOS_HP L=45n W=120n

*Inv
minvp7 nQb ne1 nVdd nVdd PMOS_HP L=45n W=180n
minvn7 nQb ne1 0 0 NMOS_HP L=45n W=120n

*NAND
mnanp1 nNanda nInv2 nVdd nVdd PMOS_HP L=45n W=180n
mnanp2 nNanda na nVdd nVdd PMOS_HP L=45n W=180n

mnann1 nNanda na nNandb 0 NMOS_HP L=45n W=120n
mnann2 nNandb nInv2 0 0 NMOS_HP L=45n W=120n

*right
mp1 na nClk nVdd nVdd PMOS_HP L=45n W=180n
mn1 na nNanda nb 0 NMOS_HP L=45n W=120n 
mn2 nb nD nc 0 NMOS_HP L=45n W=120n
mn3 nc nClk 0 0 NMOS_HP L=45n W=120n

*left
mp2 ne na1 nVdd nVdd PMOS_HP L=45n W=180n
mn4 ne nClk nf 0 NMOS_HP L=45n W=120n
mn5 nf na1 0 0 NMOS_HP L=45n W=120n

*** Output load capacitance. Capacitors should begin with "c".
* Format: <capacitor name> <node 1> <node 2> <value>
cout nQb 0 10f

* Power supply
* Format: <power supply name> <node 1> <node 2> <value>
*** Voltage source names should begin with "v".
VVdd nVdd 0 Vsup

* Input signal (independent voltage source)
* Format: <signal name> <node 1> <node 2> <signal>
* For the signal, we use a piecewise linear (PWL) source. Format: ... PWL time1 value1 time2 value2 ...

VClk nClk 0 Pulse (0 Vsup 200p 10p 10p 490p 1n)
VD nD 0 PWL 0p 0 1n 0 1.01n Vsup 2n Vsup 2.01n 0
 
* Transient analysis. Simulate up to 2.5ns.
.tran 1p 3.5n
.measure tran avg_power avg power from 1n to 3n
.end

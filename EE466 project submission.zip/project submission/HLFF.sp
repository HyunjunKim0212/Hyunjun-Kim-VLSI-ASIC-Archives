* The first line is always a comment line.
* Case-insensitive

* Control
.option post INGOLD=2

* Include the following file to load transistor models.
.include './45nm_PTM_HP_v2.1.pm'

* Parameters
* Supply voltage
.param Vsup = 1.0V

* Inverter. use NMOS_HP and PMOS_HP for NMOS and PMOS transistors.

*** Transistor names should begin with "m".
*** Use "nXXXXX" for node names.
*** Use 0 for the ground.
* Format: <transistor name> <drain> <gate> <source> <body> <type> L(Length) W(Width)

* purse generator
minvp1 nInv1 nClk nVdd nVdd PMOS_HP L=45n W=70n
minvp2 nInv2 nInv1 nVdd nVdd PMOS_HP L=45n W=70n
minvp3 nInv3 nInv2 nVdd nVdd PMOS_HP L=45n W=70n

minvn1 nInv1 nClk 0  0 NMOS_HP L=45n W=50n
mninv2 nInv2 nInv1 0 0 NMOS_HP L=45n W=50n 
mninv3 nInv3 nInv2  0 0 NMOS_HP L=45n W=50n

*Loop1
minvp4 nq1  nc  nVdd nVdd PMOS_HP L=45n W=70n
minvp5 nq nq1  nVdd nVdd PMOS_HP L=45n W=70n

minvn4 nq1 nc  0 0 NMOS_HP L=45n  W=50n
minvn5 nq nq1 0 0 NMOS_HP L=45n W=50n


*right
mp1 nx nClk nVdd nVdd PMOS_HP L=45n W=50n
mn1 nx nClk na 0 NMOS_HP L=45n W=150n 
mn2 na nD nb 0 NMOS_HP L=45n W=150n
mn3 nb  nInv3 0 0 NMOS_HP L=45n W=150n

*2nd row
mp2 nx nD nVdd nVdd PMOS_HP L=45n W=70n

*3rd row
mp3 nx nInv3 nVdd nVdd PMOS_HP L=45n W=50n

*left
mp4 nc nx nVdd nVdd PMOS_HP L=45n W=150n
mn4 nc nClk ne 0 NMOS_HP L=45n W=120n
mn5 ne nx nf 0 NMOS_HP L=45n W=120n
mn6 nf nInv3 0 0 NMOS_HP L=45n W=120n

*** Output load capacitance. Capacitors should begin with "c".
* Format: <capacitor name> <node 1> <node 2> <value>
cout nq1 0 10f

* Power supply
* Format: <power supply name> <node 1> <node 2> <value>
*** Voltage source names should begin with "v".
VVdd nVdd 0 Vsup

* Input signal (independent voltage source)
* Format: <signal name> <node 1> <node 2> <signal>
* For the signal, we use a piecewise linear (PWL) source. Format: ... PWL time1 value1 time2 value2 ...

VClk nClk 0 Pulse (0 Vsup 200p 10p 10p 490p 1n)
VD nD 0 PWL 0p 0 1n 0 1.01n Vsup 2n Vsup 2.01n 0
 
* Transient analysis. Simulate up to 2.5ns.
.tran 1p 3.5n
.measure tran avg_power avg power from 1n to 3n
.end

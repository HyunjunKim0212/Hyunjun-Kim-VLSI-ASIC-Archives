* The first line is always a comment line.
* Case-insensitive

* Control
.option post INGOLD=2

* Include the following file to load transistor models.
.include './45nm_PTM_HP_v2.1.pm'

* Parameters
.param Vsup = 1.0V

* Inverter. use NMOS_HP and PMOS_HP for NMOS and PMOS transistors.

* Transistor names should begin with "m".
.include "lab4_LVS.sp"

* Instantation. The instance name should begin with "X".
* The order of the ports should match the order of the ports in the definition.
* The last one is the name of the instance definition.
*.SUBCKT lab4 A B C Y VDD VSS
X1 nA nB nC nY nVdd 0 lab4

* Output load capacitance. Capacitors should begin with "c".
* Format: <capacitor name> <node 1> <node 2> <value>
cout nY 0 10f

* Power supply
* Format: <power supply name> <node 1> <node 2> <value>
VVdd nVdd 0 Vsup

* Input signal (independent voltage source)
* Format: <signal name> <node 1> <node 2> <signal>
* For the signal, we use a piecewise linear (PWL) source. Format: time1 value1 time2 value2 ...
* time(input): 0(000) 300(001) 600(000) 900(010) 1200(000) 1500(011) 1800(000) 2100(100) 2400(000) 2700(101) 3000(000) 3300(110) 3600(000) 3900(111) 4200(000)

VA nA 0 PWL 0p 0 2090p 0 2100p Vsup 2390p Vsup 2400p 0 2690p 0 2700p Vsup 2990p Vsup 3000p 0 3290p 0 3300p Vsup 3590p Vsup 3600p 0 3890p 0 3900p Vsup 4190p Vsup 4200p 0
VB nB 0 PWL 0p 0 890p 0 900p Vsup 1190p Vsup 1200p 0 1490p 0 1500p Vsup 1790p Vsup 1800p 0 3290p 0 3300p Vsup 3590p Vsup 3600p 0 3890p 0 3900p Vsup 4190p Vsup 4200p 0
VC nC 0 PWL 0p 0 290p 0 300p Vsup 590p Vsup 600p 0 1490p 0 1500p Vsup 1790p Vsup 1800p 0 2690p 0 2700p Vsup 2990p Vsup 3000p 0 3890p 0 3900p Vsup 4190p Vsup 4200p 0

* Transient analysis. Simulate up to 4.5ns.
.tran 1p 4.5n

* Measure (fall time)
.measure TRAN tfall TRIG V(nOut) VAL=0.9 FALL=1 TARG V(nOut) VAL=0.1 FALL=1

* Measure (rise time)
.measure TRAN trise TRIG V(nOut) VAL=0.1 RISE=1 TARG V(nOut) VAL=0.9 RISE=1

.end

